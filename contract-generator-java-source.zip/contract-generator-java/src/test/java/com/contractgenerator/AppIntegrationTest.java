package com.contractgenerator;

import com.contractgenerator.entity.Vendor;
import com.contractgenerator.entity.ContractTemplate;
import com.contractgenerator.entity.GeneratedContract;
import com.contractgenerator.service.VendorService;
import com.contractgenerator.service.TemplateService;
import com.contractgenerator.service.ContractService;
import com.contractgenerator.service.AuditService;
import com.contractgenerator.repository.VendorRepository;
import com.contractgenerator.repository.ContractTemplateRepository;
import com.contractgenerator.repository.AuditLogRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
public class AppIntegrationTest {

    @Autowired
    private VendorService vendorService;

    @Autowired
    private TemplateService templateService;

    @Autowired
    private ContractService contractService;

    @Autowired
    private AuditService auditService;

    @Autowired
    private VendorRepository vendorRepository;

    @Autowired
    private ContractTemplateRepository templateRepository;

    @Autowired
    private AuditLogRepository auditLogRepository;

    @Test
    public void testApplicationStartup() {
        assertNotNull(vendorService, "VendorService should be initialized");
        assertNotNull(templateService, "TemplateService should be initialized");
        assertNotNull(contractService, "ContractService should be initialized");
        assertNotNull(auditService, "AuditService should be initialized");
        System.out.println("✓ Application startup test PASSED");
    }

    @Test
    public void testVendorCRUD() {
        // Create
        Vendor vendor = new Vendor();
        vendor.setName("Test Company Ltd.");
        vendor.setEmail("test@example.com");
        vendor.setPhone("+1234567890");
        vendor.setAddress("123 Main St, City, Country");
        vendor.setTaxId("TAX123456");
        vendor.setContactPerson("John Doe");

        Vendor created = vendorService.create(vendor);
        assertNotNull(created.getId(), "Vendor should have ID after creation");
        System.out.println("✓ Vendor created: " + created.getName() + " (ID: " + created.getId() + ")");

        // Read
        Vendor retrieved = vendorService.getById(created.getId()).orElse(null);
        assertNotNull(retrieved, "Vendor should be retrievable");
        assertEquals("Test Company Ltd.", retrieved.getName());
        System.out.println("✓ Vendor retrieved: " + retrieved.getName());

        // Update
        retrieved.setEmail("newemail@example.com");
        Vendor updated = vendorService.update(created.getId(), retrieved);
        assertEquals("newemail@example.com", updated.getEmail());
        System.out.println("✓ Vendor updated");

        // List
        List<Vendor> allVendors = vendorService.getAll();
        assertTrue(allVendors.size() > 0, "Should have at least one vendor");
        System.out.println("✓ Vendors list contains " + allVendors.size() + " vendor(s)");

        // Cleanup
        vendorService.delete(created.getId());
        System.out.println("✓ Vendor deleted");
    }

    @Test
    public void testTemplateInitialization() {
        templateService.initializeBuiltinTemplates();

        List<ContractTemplate> builtinTemplates = templateService.getBuiltin();
        assertEquals(6, builtinTemplates.size(), "Should have 6 built-in templates");
        System.out.println("✓ Built-in templates initialized: " + builtinTemplates.size());

        for (ContractTemplate template : builtinTemplates) {
            assertNotNull(template.getName(), "Template name should not be null");
            assertNotNull(template.getFileKey(), "Template file key should not be null");
            System.out.println("  - " + template.getName());
        }
    }

    @Test
    public void testContractGeneration() {
        // Create a test vendor
        Vendor vendor = new Vendor();
        vendor.setName("Test Vendor");
        vendor.setEmail("vendor@test.com");
        vendor.setPhone("+1234567890");
        vendor.setTaxId("TAX123");
        Vendor createdVendor = vendorService.create(vendor);

        // Initialize templates
        templateService.initializeBuiltinTemplates();
        List<ContractTemplate> templates = templateService.getBuiltin();
        assertTrue(templates.size() > 0, "Should have at least one template");

        ContractTemplate template = templates.get(0);
        System.out.println("✓ Using template: " + template.getName());

        // Generate contract
        GeneratedContract contract = contractService.generateContract(
            createdVendor.getId(),
            template.getId(),
            null
        );

        assertNotNull(contract.getId(), "Generated contract should have ID");
        assertNotNull(contract.getFileName(), "Generated contract should have file name");
        System.out.println("✓ Contract generated: " + contract.getFileName());
        System.out.println("  Status: " + contract.getStatus());

        // Cleanup
        vendorService.delete(createdVendor.getId());
    }

    @Test
    public void testAuditLogging() {
        long initialCount = auditLogRepository.count();
        System.out.println("✓ Initial audit log count: " + initialCount);

        // Log some actions
        auditService.log("TEST", "VENDOR", 1L, "Test action");
        auditService.log("TEST", "CONTRACT", 2L, "Another test action");

        long finalCount = auditLogRepository.count();
        assertTrue(finalCount > initialCount, "Audit logs should increase");
        System.out.println("✓ Final audit log count: " + finalCount);
        System.out.println("✓ Logged " + (finalCount - initialCount) + " new audit entries");
    }

    @Test
    public void testFullWorkflow() {
        System.out.println("\n=== FULL WORKFLOW TEST ===\n");

        // Step 1: Create vendors
        System.out.println("Step 1: Creating vendors...");
        Vendor vendor1 = new Vendor();
        vendor1.setName("ACME Corporation");
        vendor1.setEmail("contact@acme.com");
        vendor1.setPhone("+1-800-ACME");
        vendor1.setAddress("123 Tech Road, Silicon Valley, CA");
        vendor1.setTaxId("US123456789");
        vendor1.setContactPerson("Jane Smith");

        Vendor vendor2 = new Vendor();
        vendor2.setName("Global Ventures Inc");
        vendor2.setEmail("info@globalventures.com");
        vendor2.setPhone("+44-20-1234");
        vendor2.setAddress("456 Business Ave, London, UK");
        vendor2.setTaxId("GB987654321");
        vendor2.setContactPerson("Bob Wilson");

        Vendor v1 = vendorService.create(vendor1);
        Vendor v2 = vendorService.create(vendor2);
        System.out.println("✓ Created 2 vendors");

        // Step 2: Initialize templates
        System.out.println("\nStep 2: Initializing templates...");
        templateService.initializeBuiltinTemplates();
        List<ContractTemplate> templates = templateService.getBuiltin();
        System.out.println("✓ Initialized " + templates.size() + " templates");

        // Step 3: Generate contracts
        System.out.println("\nStep 3: Generating contracts...");
        int generated = 0;
        for (Vendor v : new Vendor[]{v1, v2}) {
            for (ContractTemplate t : templates.subList(0, Math.min(2, templates.size()))) {
                GeneratedContract contract = contractService.generateContract(v.getId(), t.getId(), null);
                if ("success".equals(contract.getStatus())) {
                    generated++;
                    System.out.println("  ✓ " + v.getName() + " → " + t.getName());
                }
            }
        }
        System.out.println("✓ Generated " + generated + " contracts");

        // Step 4: Check audit log
        System.out.println("\nStep 4: Checking audit log...");
        long auditCount = auditLogRepository.count();
        System.out.println("✓ Total audit log entries: " + auditCount);

        // Cleanup
        System.out.println("\nStep 5: Cleanup...");
        vendorService.delete(v1.getId());
        vendorService.delete(v2.getId());
        System.out.println("✓ Deleted test vendors");

        System.out.println("\n=== FULL WORKFLOW TEST PASSED ===\n");
    }
}
