package com.contractgenerator.repository;

import com.contractgenerator.entity.ContractTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ContractTemplateRepository extends JpaRepository<ContractTemplate, Long> {
    List<ContractTemplate> findByIsBuiltin(Integer isBuiltin);
    Optional<ContractTemplate> findByFileKey(String fileKey);
    List<ContractTemplate> findByNameContainingIgnoreCase(String name);
}
