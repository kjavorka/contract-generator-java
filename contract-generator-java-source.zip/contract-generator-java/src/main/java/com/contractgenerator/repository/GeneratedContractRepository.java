package com.contractgenerator.repository;

import com.contractgenerator.entity.GeneratedContract;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GeneratedContractRepository extends JpaRepository<GeneratedContract, Long> {
    List<GeneratedContract> findByVendorId(Long vendorId);
    List<GeneratedContract> findByTemplateId(Long templateId);
    List<GeneratedContract> findByStatus(String status);
    void deleteByVendorId(Long vendorId);
}
