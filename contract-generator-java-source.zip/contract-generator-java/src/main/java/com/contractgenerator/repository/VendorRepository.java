package com.contractgenerator.repository;

import com.contractgenerator.entity.Vendor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VendorRepository extends JpaRepository<Vendor, Long> {
    List<Vendor> findByNameContainingIgnoreCase(String name);
    Vendor findByEmail(String email);
}
