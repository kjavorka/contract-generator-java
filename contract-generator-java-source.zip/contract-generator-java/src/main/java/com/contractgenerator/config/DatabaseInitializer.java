package com.contractgenerator.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class DatabaseInitializer {

    @Bean
    CommandLineRunner initializeDatabase(JdbcTemplate jdbcTemplate) {
        return args -> {
            try {
                String[] tables = {
                    "CREATE TABLE IF NOT EXISTS vendors (id BIGINT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, email VARCHAR(255), phone VARCHAR(20), address TEXT, tax_id VARCHAR(50), contact_person VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
                    "CREATE TABLE IF NOT EXISTS contract_templates (id BIGINT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, filename VARCHAR(255), file_key VARCHAR(255) UNIQUE, description TEXT, is_builtin INTEGER DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)",
                    "CREATE TABLE IF NOT EXISTS generated_contracts (id BIGINT AUTO_INCREMENT PRIMARY KEY, vendor_id BIGINT, template_id BIGINT, file_path VARCHAR(255), file_name VARCHAR(255), status VARCHAR(50) DEFAULT 'success', error_message TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (vendor_id) REFERENCES vendors(id), FOREIGN KEY (template_id) REFERENCES contract_templates(id))",
                    "CREATE TABLE IF NOT EXISTS audit_logs (id BIGINT AUTO_INCREMENT PRIMARY KEY, action VARCHAR(50) NOT NULL, entity_type VARCHAR(50) NOT NULL, entity_id BIGINT, details TEXT, timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"
                };

                for (String sql : tables) {
                    jdbcTemplate.execute(sql);
                }
                System.out.println("✓ Database schema initialized successfully");
            } catch (Exception e) {
                System.err.println("Database schema already exists or already initialized");
            }
        };
    }
}
