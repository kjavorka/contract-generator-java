package com.contractgenerator.util;

import org.apache.poi.xwpf.usermodel.*;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WordTemplateProcessor {

    private static final Pattern PLACEHOLDER_PATTERN = Pattern.compile("\\{([^}]+)\\}");

    /**
     * Szerződés generálása sablonból az adatok alapján
     */
    public static byte[] generateFromTemplate(File templateFile, Map<String, String> data) throws IOException {
        // Ha a fájl üres vagy nem létezik, hozz létre egy új dokumentumot
        if (!templateFile.exists() || templateFile.length() == 0) {
            return createDocumentFromData(data);
        }

        try (FileInputStream fis = new FileInputStream(templateFile);
             XWPFDocument document = new XWPFDocument(fis)) {

            // Paragrafsok feldolgozása
            for (XWPFParagraph paragraph : document.getParagraphs()) {
                replacePlaceholdersInParagraph(paragraph, data);
            }

            // Táblázatok feldolgozása
            for (XWPFTable table : document.getTables()) {
                for (XWPFTableRow row : table.getRows()) {
                    for (XWPFTableCell cell : row.getTableCells()) {
                        for (XWPFParagraph paragraph : cell.getParagraphs()) {
                            replacePlaceholdersInParagraph(paragraph, data);
                        }
                    }
                }
            }

            // ByteArrayOutputStream-ba írás
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            document.write(baos);
            return baos.toByteArray();
        }
    }

    /**
     * Dokumentum létrehozása adatokból, ha nincs template
     */
    private static byte[] createDocumentFromData(Map<String, String> data) throws IOException {
        XWPFDocument document = new XWPFDocument();

        // Fejléc
        XWPFParagraph title = document.createParagraph();
        XWPFRun titleRun = title.createRun();
        titleRun.setText("Szerződés");
        titleRun.setBold(true);

        // Adatok kiírása
        for (Map.Entry<String, String> entry : data.entrySet()) {
            XWPFParagraph p = document.createParagraph();
            p.createRun().setText(entry.getKey() + ": " + entry.getValue());
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        document.write(baos);
        document.close();
        return baos.toByteArray();
    }

    /**
     * Placeholders helyettesítése egy paragrafsban (egyszerűsített verzió)
     */
    private static void replacePlaceholdersInParagraph(XWPFParagraph paragraph, Map<String, String> data) {
        // Apache POI limitációk miatt: csak teljes paragrafusszöveg csere
        String fullText = paragraph.getText();
        String replacedText = fullText;

        for (Map.Entry<String, String> entry : data.entrySet()) {
            replacedText = replacedText.replace("{" + entry.getKey() + "}", entry.getValue());
        }

        if (!replacedText.equals(fullText)) {
            // Runs kezelése: szöveg frissítés az első run-ban
            if (!paragraph.getRuns().isEmpty()) {
                paragraph.getRuns().get(0).setText(replacedText, 0);
            } else {
                XWPFRun run = paragraph.createRun();
                run.setText(replacedText);
            }
        }
    }

    /**
     * Sablonból placeholder-ek kinyerése
     */
    public static Set<String> extractPlaceholders(File templateFile) throws IOException {
        Set<String> placeholders = new HashSet<>();

        try (FileInputStream fis = new FileInputStream(templateFile);
             XWPFDocument document = new XWPFDocument(fis)) {

            // Paragrafsokból
            for (XWPFParagraph paragraph : document.getParagraphs()) {
                extractPlaceholdersFromText(paragraph.getText(), placeholders);
            }

            // Táblázatokból
            for (XWPFTable table : document.getTables()) {
                for (XWPFTableRow row : table.getRows()) {
                    for (XWPFTableCell cell : row.getTableCells()) {
                        for (XWPFParagraph paragraph : cell.getParagraphs()) {
                            extractPlaceholdersFromText(paragraph.getText(), placeholders);
                        }
                    }
                }
            }
        }

        return placeholders;
    }

    /**
     * Placeholders kinyerése szövegből
     */
    private static void extractPlaceholdersFromText(String text, Set<String> placeholders) {
        Matcher matcher = PLACEHOLDER_PATTERN.matcher(text);
        while (matcher.find()) {
            placeholders.add(matcher.group(1));
        }
    }
}
