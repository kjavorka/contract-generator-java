package com.contractgenerator.util;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.*;

public class PdfGenerator {

    /**
     * Word (DOCX) fájlból PDF-et generál
     * Megjegyzés: Teljes conversion iText-szel szükséges külső lib (Apache POI + Aspose)
     * Ezért egyszerűsítésként csak placeholder: később Aspose-t vagy LibreOffice-t lehet használni
     */
    public static byte[] convertDocxToPdf(byte[] docxContent) {
        // Valós implementáció: Aspose.Words vagy LibreOffice conversion
        // Jelenlegi placeholder: csak validál, hogy a fájl létezik

        try {
            // Egyszerű PDF placeholder
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            Document document = new Document();
            PdfWriter.getInstance(document, baos);
            document.open();
            document.addTitle("Generated Contract");
            document.addSubject("Contract from Template");
            document.addAuthor("Contract Generator");
            document.close();

            return baos.toByteArray();
        } catch (DocumentException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * File-ból PDF generál
     */
    public static void saveToPdf(byte[] content, File outputFile) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            fos.write(content);
        }
    }

    /**
     * Docx-ből PDF-et generál és fájlba menti
     */
    public static boolean convertAndSave(File docxFile, File pdfFile) {
        try {
            byte[] docxContent = readFileToBytes(docxFile);
            byte[] pdfContent = convertDocxToPdf(docxContent);

            if (pdfContent == null) {
                return false;
            }

            saveToPdf(pdfContent, pdfFile);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Fájl olvasása byte array-be
     */
    private static byte[] readFileToBytes(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                baos.write(buffer, 0, bytesRead);
            }
            return baos.toByteArray();
        }
    }
}
