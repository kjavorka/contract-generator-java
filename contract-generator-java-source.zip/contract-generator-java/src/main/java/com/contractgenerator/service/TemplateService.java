package com.contractgenerator.service;

import com.contractgenerator.entity.ContractTemplate;
import com.contractgenerator.repository.ContractTemplateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class TemplateService {

    @Autowired
    private ContractTemplateRepository templateRepository;

    @Autowired
    private AuditService auditService;

    public void initializeBuiltinTemplates() {
        if (templateRepository.findByIsBuiltin(1).isEmpty()) {
            String[][] templates = {
                {"Zmluva o poskytovaní služieb (Croner)", "3-Croner_Zmluva o poskytovaní služieb.docx", "template_croner_1", "Service agreement (Croner)"},
                {"Nová Zmluva o pouzivani reklamnych predmetov (Croner)", "4-Croner_Nová Zmluva o pouzivani reklamnych predmetov.docx", "template_croner_2", "Advertising usage (Croner)"},
                {"Dodatok c1 zoznam zakaznickych poziadaviek (Croner)", "5-Croner_Dodatok c1 zoznam zakaznickych poziadaviek.docx", "template_croner_3", "Amendment 1 (Croner)"},
                {"Nová Zmluva o pouzivani reklamnych predmetov (AGRIOS)", "7-AGRIOS_Nová Zmluva o pouzivani reklamnych predmetov.docx", "template_agrios_1", "Advertising usage (AGRIOS)"},
                {"Szerződéskiegészítés természetes személlyel", "7-számú melléklet szerződéskiegészítés természetes személlyel.doc", "template_hu_1", "Contract amendment (HU)"},
                {"Dodatok c1 zoznam zakaznickych poziadaviek (AGRIOS)", "8-AGRIOS_Dodatok c1 zoznam zakaznickych poziadaviek copy.docx", "template_agrios_2", "Amendment 1 (AGRIOS)"}
            };

            for (String[] t : templates) {
                ContractTemplate template = new ContractTemplate();
                template.setName(t[0]);
                template.setFilename(t[1]);
                template.setFileKey(t[2]);
                template.setDescription(t[3]);
                template.setIsBuiltin(1);
                template.setCreatedAt(LocalDateTime.now());
                template.setUpdatedAt(LocalDateTime.now());
                templateRepository.save(template);
            }
        }
    }

    public ContractTemplate create(ContractTemplate template) {
        template.setCreatedAt(LocalDateTime.now());
        template.setUpdatedAt(LocalDateTime.now());
        ContractTemplate saved = templateRepository.save(template);
        auditService.log("CREATE", "TEMPLATE", saved.getId(), "Created template: " + saved.getName());
        return saved;
    }

    public void delete(Long id) {
        ContractTemplate template = templateRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Template not found"));
        templateRepository.deleteById(id);
        auditService.log("DELETE", "TEMPLATE", id, "Deleted template: " + template.getName());
    }

    public Optional<ContractTemplate> getById(Long id) {
        return templateRepository.findById(id);
    }

    public List<ContractTemplate> getAll() {
        return templateRepository.findAll();
    }

    public List<ContractTemplate> getBuiltin() {
        return templateRepository.findByIsBuiltin(1);
    }

    public List<ContractTemplate> getCustom() {
        return templateRepository.findByIsBuiltin(0);
    }

    public long count() {
        return templateRepository.count();
    }
}
