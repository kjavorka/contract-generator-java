package com.contractgenerator.service;

import com.contractgenerator.entity.Vendor;
import com.contractgenerator.repository.VendorRepository;
import com.contractgenerator.repository.GeneratedContractRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class VendorService {

    @Autowired
    private VendorRepository vendorRepository;

    @Autowired
    private GeneratedContractRepository contractRepository;

    @Autowired
    private AuditService auditService;

    public Vendor create(Vendor vendor) {
        vendor.setCreatedAt(LocalDateTime.now());
        vendor.setUpdatedAt(LocalDateTime.now());
        Vendor saved = vendorRepository.save(vendor);
        auditService.log("CREATE", "VENDOR", saved.getId(), "Created vendor: " + saved.getName());
        return saved;
    }

    public Vendor update(Long id, Vendor vendorData) {
        Vendor vendor = vendorRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Vendor not found"));

        vendor.setName(vendorData.getName());
        vendor.setEmail(vendorData.getEmail());
        vendor.setPhone(vendorData.getPhone());
        vendor.setAddress(vendorData.getAddress());
        vendor.setTaxId(vendorData.getTaxId());
        vendor.setContactPerson(vendorData.getContactPerson());
        vendor.setUpdatedAt(LocalDateTime.now());

        Vendor updated = vendorRepository.save(vendor);
        auditService.log("UPDATE", "VENDOR", id, "Updated vendor: " + updated.getName());
        return updated;
    }

    public void delete(Long id) {
        Vendor vendor = vendorRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Vendor not found"));
        // Első lépésben töröljük a szerződéseket
        contractRepository.deleteByVendorId(id);
        vendorRepository.deleteById(id);
        auditService.log("DELETE", "VENDOR", id, "Deleted vendor: " + vendor.getName());
    }

    public Optional<Vendor> getById(Long id) {
        return vendorRepository.findById(id);
    }

    public List<Vendor> getAll() {
        return vendorRepository.findAll();
    }

    public List<Vendor> search(String query) {
        return vendorRepository.findByNameContainingIgnoreCase(query);
    }

    public long count() {
        return vendorRepository.count();
    }
}
