package com.contractgenerator.service;

import com.contractgenerator.entity.GeneratedContract;
import com.contractgenerator.entity.ContractTemplate;
import com.contractgenerator.entity.Vendor;
import com.contractgenerator.repository.GeneratedContractRepository;
import com.contractgenerator.util.WordTemplateProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class ContractService {

    @Autowired
    private GeneratedContractRepository contractRepository;

    @Autowired
    private VendorService vendorService;

    @Autowired
    private TemplateService templateService;

    @Autowired
    private AuditService auditService;

    private static final String OUTPUT_DIR = "./generated-contracts";

    /**
     * Szerződés generálása
     */
    public GeneratedContract generateContract(Long vendorId, Long templateId, Map<String, String> dataOverride) {
        try {
            // Entitások betöltése
            Vendor vendor = vendorService.getById(vendorId)
                .orElseThrow(() -> new RuntimeException("Vendor not found"));
            ContractTemplate template = templateService.getById(templateId)
                .orElseThrow(() -> new RuntimeException("Template not found"));

            // Output mappa létrehozása
            ensureOutputDirExists();

            // Sablon fájl útvonala (egyszerűsítésre: a template fájlnevet használjuk)
            File templateFile = new File(OUTPUT_DIR, template.getFilename());
            if (!templateFile.exists()) {
                // Ha nem létezik, akkor placeholder fájlt készítünk
                createPlaceholderTemplate(templateFile);
            }

            // Adatok előkészítése
            Map<String, String> data = prepareData(vendor, dataOverride);

            // Szerződés generálása Apache POI-val
            byte[] contractBytes = WordTemplateProcessor.generateFromTemplate(templateFile, data);

            // Kimeneti fájl mentése
            String fileName = String.format("%s_%s_%d.docx",
                vendor.getName().replace(" ", "_"),
                template.getName().replace(" ", "_"),
                System.currentTimeMillis());
            File outputFile = new File(OUTPUT_DIR, fileName);

            try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                fos.write(contractBytes);
            }

            // Adatbázisba mentés
            GeneratedContract contract = new GeneratedContract();
            contract.setVendor(vendor);
            contract.setTemplate(template);
            // Megjegyzés: setDataJson nincs az entitáson - details a fileName-ben tárolva
            contract.setFilePath(outputFile.getAbsolutePath());
            contract.setFileName(fileName);
            contract.setStatus("success");
            contract.setCreatedAt(LocalDateTime.now());

            GeneratedContract saved = contractRepository.save(contract);

            // Audit
            auditService.log("GENERATE", "CONTRACT", saved.getId(),
                String.format("Generated contract for %s using %s", vendor.getName(), template.getName()));

            return saved;
        } catch (IOException e) {
            // Hiba esetén
            GeneratedContract errorContract = new GeneratedContract();
            errorContract.setStatus("error");
            errorContract.setErrorMessage(e.getMessage());
            errorContract.setCreatedAt(LocalDateTime.now());

            GeneratedContract saved = contractRepository.save(errorContract);
            auditService.log("GENERATE_ERROR", "CONTRACT", saved.getId(), "Error: " + e.getMessage());

            return saved;
        }
    }

    /**
     * Adatok előkészítése
     */
    private Map<String, String> prepareData(Vendor vendor, Map<String, String> override) {
        Map<String, String> data = new HashMap<>();

        // Alapadatok
        data.put("vendorName", vendor.getName() != null ? vendor.getName() : "");
        data.put("vendorEmail", vendor.getEmail() != null ? vendor.getEmail() : "");
        data.put("vendorPhone", vendor.getPhone() != null ? vendor.getPhone() : "");
        data.put("vendorAddress", vendor.getAddress() != null ? vendor.getAddress() : "");
        data.put("vendorTaxId", vendor.getTaxId() != null ? vendor.getTaxId() : "");
        data.put("vendorContactPerson", vendor.getContactPerson() != null ? vendor.getContactPerson() : "");
        data.put("generationDate", LocalDateTime.now().toString());

        // Override
        if (override != null) {
            data.putAll(override);
        }

        return data;
    }

    /**
     * Generált szerződések listája
     */
    public List<GeneratedContract> getAll() {
        return contractRepository.findAll();
    }

    /**
     * Szállító szerződéseinek listája
     */
    public List<GeneratedContract> getByVendor(Long vendorId) {
        return contractRepository.findByVendorId(vendorId);
    }

    /**
     * Output mappa létrehozása
     */
    private void ensureOutputDirExists() {
        File dir = new File(OUTPUT_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    /**
     * Placeholder template fájl létrehozása
     */
    private void createPlaceholderTemplate(File templateFile) throws IOException {
        if (!templateFile.exists()) {
            // Valós sablonok helyett placeholder - később feltölteni kell az igazi .docx fájlokat
            // Ebben az esetben az alkalmazás azt jelzi, hogy szükséges a sablon
            templateFile.createNewFile();
        }
    }
}
