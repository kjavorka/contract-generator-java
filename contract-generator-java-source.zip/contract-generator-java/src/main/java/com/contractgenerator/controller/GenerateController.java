package com.contractgenerator.controller;

import com.contractgenerator.entity.GeneratedContract;
import com.contractgenerator.entity.Vendor;
import com.contractgenerator.entity.ContractTemplate;
import com.contractgenerator.service.ContractService;
import com.contractgenerator.service.VendorService;
import com.contractgenerator.service.TemplateService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class GenerateController {

    @Autowired
    private ContractService contractService;

    @Autowired
    private VendorService vendorService;

    @Autowired
    private TemplateService templateService;

    @FXML
    private ComboBox<Vendor> vendorCombo;

    @FXML
    private ComboBox<ContractTemplate> templateCombo;

    @FXML
    private CheckBox saveDocxCheckBox;

    @FXML
    private CheckBox exportPdfCheckBox;

    @FXML
    private CheckBox printCheckBox;

    @FXML
    private Button generateButton;

    @FXML
    private Label statusLabel;

    @FXML
    public void initialize() {
        System.out.println("✓ GenerateController initialized");

        setupCombos();
        setupEventHandlers();
        saveDocxCheckBox.setSelected(true);
    }

    private void setupCombos() {
        List<Vendor> vendors = vendorService.getAll();
        ObservableList<Vendor> vendorList = FXCollections.observableArrayList(vendors);
        vendorCombo.setItems(vendorList);
        if (!vendorList.isEmpty()) vendorCombo.getSelectionModel().selectFirst();

        List<ContractTemplate> templates = templateService.getAll();
        ObservableList<ContractTemplate> templateList = FXCollections.observableArrayList(templates);
        templateCombo.setItems(templateList);
        if (!templateList.isEmpty()) templateCombo.getSelectionModel().selectFirst();
    }

    private void setupEventHandlers() {
        generateButton.setOnAction(e -> generateContract());
    }

    private void generateContract() {
        Vendor vendor = vendorCombo.getValue();
        ContractTemplate template = templateCombo.getValue();

        if (vendor == null || template == null) {
            showError("Please select a vendor and template");
            return;
        }

        try {
            updateStatus("Generating contract...");
            GeneratedContract contract = contractService.generateContract(vendor.getId(), template.getId(), new HashMap<>());

            if ("success".equals(contract.getStatus())) {
                handleSuccess(contract);
            } else {
                showError("Failed: " + contract.getErrorMessage());
            }
        } catch (Exception e) {
            showError("Error: " + e.getMessage());
        }
    }

    private void handleSuccess(GeneratedContract contract) {
        if (saveDocxCheckBox.isSelected()) saveDocxFile(contract);
        if (exportPdfCheckBox.isSelected()) showInfo("PDF Export", "PDF export requires external library");
        if (printCheckBox.isSelected()) showInfo("Print", "File: " + contract.getFileName());

        updateStatus("✓ Contract generated!");
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Contract Generated");
        alert.setContentText("Saved: " + contract.getFileName());
        alert.showAndWait();
    }

    private void saveDocxFile(GeneratedContract contract) {
        try {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save Contract");
            fileChooser.setInitialFileName(contract.getFileName());
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Word Documents", "*.docx"));

            File selectedFile = fileChooser.showSaveDialog(generateButton.getScene().getWindow());
            if (selectedFile != null) {
                java.nio.file.Files.copy(
                    new File(contract.getFilePath()).toPath(),
                    selectedFile.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING
                );
                updateStatus("✓ Saved: " + selectedFile.getAbsolutePath());
            }
        } catch (Exception e) {
            showError("Failed to save: " + e.getMessage());
        }
    }

    private void updateStatus(String message) {
        statusLabel.setText(message);
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
