package com.contractgenerator.controller;

import com.contractgenerator.entity.Vendor;
import com.contractgenerator.service.VendorService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.geometry.Insets;
import javafx.scene.layout.GridPane;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class VendorController {

    @Autowired
    private VendorService vendorService;

    @FXML
    private TableView<Vendor> vendorTable;
    @FXML
    private TableColumn<Vendor, Long> idColumn;
    @FXML
    private TableColumn<Vendor, String> nameColumn;
    @FXML
    private TableColumn<Vendor, String> emailColumn;
    @FXML
    private TableColumn<Vendor, String> phoneColumn;
    @FXML
    private TableColumn<Vendor, String> addressColumn;
    @FXML
    private TableColumn<Vendor, String> actionColumn;

    @FXML
    private TextField searchField;
    @FXML
    private Button addButton;
    @FXML
    private Button importButton;

    private ObservableList<Vendor> vendorList;
    private Vendor selectedVendor;

    @FXML
    public void initialize() {
        System.out.println("✓ VendorController initialized");

        setupTableColumns();
        loadVendors();
        setupEventHandlers();
    }

    private void setupTableColumns() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));

        // Action column
        actionColumn.setCellFactory(param -> new TableCell<Vendor, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || getTableRow() == null) {
                    setGraphic(null);
                } else {
                    Vendor vendor = getTableRow().getItem();
                    Button editBtn = new Button("Edit");
                    Button deleteBtn = new Button("Delete");

                    editBtn.setOnAction(e -> editVendor(vendor));
                    deleteBtn.setOnAction(e -> deleteVendor(vendor));
                    deleteBtn.setStyle("-fx-text-fill: white; -fx-background-color: #dc3545;");

                    GridPane pane = new GridPane();
                    pane.setHgap(5);
                    pane.add(editBtn, 0, 0);
                    pane.add(deleteBtn, 1, 0);

                    setGraphic(pane);
                }
            }
        });

        vendorTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    private void loadVendors() {
        vendorList = FXCollections.observableArrayList(vendorService.getAll());
        vendorTable.setItems(vendorList);
    }

    private void setupEventHandlers() {
        searchField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal.isEmpty()) {
                loadVendors();
            } else {
                ObservableList<Vendor> filtered = FXCollections.observableArrayList(
                    vendorService.search(newVal)
                );
                vendorTable.setItems(filtered);
            }
        });

        addButton.setOnAction(e -> showVendorDialog(null));
        importButton.setOnAction(e -> showImportDialog());
    }

    private void editVendor(Vendor vendor) {
        selectedVendor = vendor;
        showVendorDialog(vendor);
    }

    private void deleteVendor(Vendor vendor) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Vendor");
        alert.setHeaderText("Delete " + vendor.getName());
        alert.setContentText("Are you sure you want to delete this vendor?");

        if (alert.showAndWait().get() == ButtonType.OK) {
            vendorService.delete(vendor.getId());
            loadVendors();
        }
    }

    private void showVendorDialog(Vendor vendor) {
        Dialog<Vendor> dialog = new Dialog<>();
        dialog.setTitle(vendor == null ? "Add Vendor" : "Edit Vendor");
        dialog.setHeaderText(vendor == null ? "Add a new vendor" : "Edit vendor");

        // Form fields
        TextField nameField = new TextField();
        TextField emailField = new TextField();
        TextField phoneField = new TextField();
        TextArea addressArea = new TextArea();
        TextField taxIdField = new TextField();
        TextField contactPersonField = new TextField();

        if (vendor != null) {
            nameField.setText(vendor.getName());
            emailField.setText(vendor.getEmail() != null ? vendor.getEmail() : "");
            phoneField.setText(vendor.getPhone() != null ? vendor.getPhone() : "");
            addressArea.setText(vendor.getAddress() != null ? vendor.getAddress() : "");
            taxIdField.setText(vendor.getTaxId() != null ? vendor.getTaxId() : "");
            contactPersonField.setText(vendor.getContactPerson() != null ? vendor.getContactPerson() : "");
        }

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        grid.add(new Label("Name:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Email:"), 0, 1);
        grid.add(emailField, 1, 1);
        grid.add(new Label("Phone:"), 0, 2);
        grid.add(phoneField, 1, 2);
        grid.add(new Label("Address:"), 0, 3);
        grid.add(addressArea, 1, 3);
        grid.add(new Label("Tax ID:"), 0, 4);
        grid.add(taxIdField, 1, 4);
        grid.add(new Label("Contact Person:"), 0, 5);
        grid.add(contactPersonField, 1, 5);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                Vendor result = vendor != null ? vendor : new Vendor();
                result.setName(nameField.getText());
                result.setEmail(emailField.getText());
                result.setPhone(phoneField.getText());
                result.setAddress(addressArea.getText());
                result.setTaxId(taxIdField.getText());
                result.setContactPerson(contactPersonField.getText());
                return result;
            }
            return null;
        });

        dialog.showAndWait().ifPresent(result -> {
            if (vendor == null) {
                vendorService.create(result);
            } else {
                vendorService.update(result.getId(), result);
            }
            loadVendors();
        });
    }

    private void showImportDialog() {
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Import CSV");
        dialog.setHeaderText("Import vendors from CSV");

        TextArea csvArea = new TextArea();
        csvArea.setPromptText("Paste CSV data here (format: name,email,phone,address,tax_id,contact_person)");
        csvArea.setWrapText(true);

        dialog.getDialogPane().setContent(csvArea);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                return csvArea.getText();
            }
            return null;
        });

        dialog.showAndWait().ifPresent(csvData -> {
            try {
                importVendorsFromCsv(csvData);
                loadVendors();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Import Success");
                alert.setHeaderText("Vendors imported successfully");
                alert.showAndWait();
            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Import Error");
                alert.setHeaderText("Failed to import vendors");
                alert.setContentText(e.getMessage());
                alert.showAndWait();
            }
        });
    }

    private void importVendorsFromCsv(String csvData) {
        String[] lines = csvData.split("\n");
        for (String line : lines) {
            if (line.trim().isEmpty()) continue;

            String[] fields = line.split(",");
            if (fields.length >= 1) {
                Vendor vendor = new Vendor();
                vendor.setName(fields.length > 0 ? fields[0].trim() : "");
                vendor.setEmail(fields.length > 1 ? fields[1].trim() : "");
                vendor.setPhone(fields.length > 2 ? fields[2].trim() : "");
                vendor.setAddress(fields.length > 3 ? fields[3].trim() : "");
                vendor.setTaxId(fields.length > 4 ? fields[4].trim() : "");
                vendor.setContactPerson(fields.length > 5 ? fields[5].trim() : "");

                vendorService.create(vendor);
            }
        }
    }
}
