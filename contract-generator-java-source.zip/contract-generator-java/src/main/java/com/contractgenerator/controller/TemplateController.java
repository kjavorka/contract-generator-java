package com.contractgenerator.controller;

import com.contractgenerator.entity.ContractTemplate;
import com.contractgenerator.service.TemplateService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class TemplateController {

    @Autowired
    private TemplateService templateService;

    @FXML
    private TableView<ContractTemplate> templateTable;

    @FXML
    private TableColumn<ContractTemplate, String> nameColumn;
    @FXML
    private TableColumn<ContractTemplate, String> filenameColumn;
    @FXML
    private TableColumn<ContractTemplate, String> typeColumn;
    @FXML
    private TableColumn<ContractTemplate, String> actionColumn;

    @FXML
    public void initialize() {
        System.out.println("✓ TemplateController initialized");
        setupTableColumns();
        loadTemplates();
    }

    private void setupTableColumns() {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        filenameColumn.setCellValueFactory(new PropertyValueFactory<>("filename"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("isBuiltin"));

        actionColumn.setCellFactory(param -> new TableCell<ContractTemplate, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || getTableRow() == null) {
                    setGraphic(null);
                } else {
                    ContractTemplate template = getTableRow().getItem();
                    Button deleteBtn = new Button("Delete");
                    deleteBtn.setStyle("-fx-text-fill: white; -fx-background-color: #dc3545;");
                    deleteBtn.setOnAction(e -> deleteTemplate(template));
                    setGraphic(deleteBtn);
                }
            }
        });

        templateTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    private void loadTemplates() {
        ObservableList<ContractTemplate> templates = FXCollections.observableArrayList(
            templateService.getAll()
        );
        templateTable.setItems(templates);
    }

    private void deleteTemplate(ContractTemplate template) {
        if (template.getIsBuiltin() == 1) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Cannot Delete");
            alert.setContentText("Built-in templates cannot be deleted");
            alert.showAndWait();
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Delete Template");
        confirm.setContentText("Delete " + template.getName() + "?");

        if (confirm.showAndWait().get() == ButtonType.OK) {
            templateService.delete(template.getId());
            loadTemplates();
        }
    }
}
