package com.contractgenerator.controller;

import com.contractgenerator.service.TemplateService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.AnchorPane;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.io.IOException;

@Controller
public class MainController {

    @Autowired
    private TemplateService templateService;

    @FXML
    private TabPane tabPane;

    @FXML
    private Tab vendorTab;

    @FXML
    private Tab templateTab;

    @FXML
    private Tab generateTab;

    @FXML
    private Tab auditTab;

    @FXML
    public void initialize() {
        // Initialize built-in templates on startup
        templateService.initializeBuiltinTemplates();

        // Load sub-controllers for each tab
        loadTabContent(vendorTab, "/fxml/vendor-tab.fxml");
        loadTabContent(templateTab, "/fxml/template-tab.fxml");
        loadTabContent(generateTab, "/fxml/generate-tab.fxml");
        loadTabContent(auditTab, "/fxml/audit-tab.fxml");
    }

    private void loadTabContent(Tab tab, String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            loader.setControllerFactory(c -> {
                try {
                    return ContractGeneratorApplication.getSpringContext().getBean(c);
                } catch (Exception e) {
                    return null;
                }
            });
            AnchorPane content = loader.load();
            tab.setContent(content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static class ContractGeneratorApplication {
        static org.springframework.context.ConfigurableApplicationContext getSpringContext() {
            return com.contractgenerator.ContractGeneratorApplication.getSpringContext();
        }
    }
}
