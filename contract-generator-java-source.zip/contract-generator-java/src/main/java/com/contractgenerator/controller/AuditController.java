package com.contractgenerator.controller;

import com.contractgenerator.entity.AuditLog;
import com.contractgenerator.service.AuditService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class AuditController {

    @Autowired
    private AuditService auditService;

    @FXML
    private TableView<AuditLog> auditTable;

    @FXML
    private TableColumn<AuditLog, String> actionColumn;
    @FXML
    private TableColumn<AuditLog, String> entityTypeColumn;
    @FXML
    private TableColumn<AuditLog, Long> entityIdColumn;
    @FXML
    private TableColumn<AuditLog, String> timestampColumn;

    @FXML
    private Button clearButton;

    @FXML
    public void initialize() {
        System.out.println("✓ AuditController initialized");
        setupTableColumns();
        loadLogs();
        clearButton.setOnAction(e -> clearLogs());
    }

    private void setupTableColumns() {
        actionColumn.setCellValueFactory(new PropertyValueFactory<>("action"));
        entityTypeColumn.setCellValueFactory(new PropertyValueFactory<>("entityType"));
        entityIdColumn.setCellValueFactory(new PropertyValueFactory<>("entityId"));
        timestampColumn.setCellValueFactory(cellData -> {
            String timestamp = cellData.getValue().getTimestamp().toString();
            return new javafx.beans.property.SimpleStringProperty(timestamp);
        });

        auditTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    private void loadLogs() {
        ObservableList<AuditLog> logs = FXCollections.observableArrayList(
            auditService.getAll()
        );
        auditTable.setItems(logs);
    }

    private void clearLogs() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Clear Logs");
        confirm.setContentText("Clear all audit logs? This cannot be undone.");

        if (confirm.showAndWait().get() == ButtonType.OK) {
            auditService.clear();
            loadLogs();
        }
    }
}
