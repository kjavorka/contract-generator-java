# Contract Generator - Java Desktop Application

A modern **JavaFX Desktop Application** for managing vendors and generating Word contracts from templates.

## 🎯 Features

- ✅ **Vendor Management** - Add, edit, delete vendors (CRUD)
- ✅ **CSV Import** - Bulk import vendors from CSV files
- ✅ **Contract Templates** - 6 built-in templates + custom upload
- ✅ **Contract Generation** - Generate .docx from templates + vendor data
- ✅ **PDF Export** - Convert generated contracts to PDF
- ✅ **Print Support** - Direct printing of contracts
- ✅ **Audit Logging** - Track all operations
- ✅ **SQLite Database** - Beépített, nincs külső DB szükséges
- ✅ **Modern UI** - JavaFX with CSS styling
- ✅ **Cross-platform** - Windows, macOS, Linux

## 📋 Tech Stack

- **Framework**: Spring Boot 3.3.0 + JavaFX 21
- **Database**: SQLite + JPA/Hibernate
- **Word Processing**: Apache POI 5.0.0
- **PDF**: iText 5.5
- **CSV**: OpenCSV 5.9
- **Build**: Maven 3.9+
- **Java**: JDK 17+

## 🚀 Quick Start

### Prerequisites
```bash
# Install Java 17+
java -version

# Install Maven
mvn -version
```

### Build

```bash
cd contract-generator-java
mvn clean package
```

Output: `target/contract-generator.jar`

### Run

**Windows/macOS/Linux:**
```bash
java -jar target/contract-generator.jar
```

**macOS (direct):**
```bash
open target/contract-generator.jar
```

### Development

```bash
# Run with Maven
mvn spring-boot:run

# Or in IDE (IntelliJ/Eclipse)
Run ContractGeneratorApplication.java
```

## 📁 Project Structure

```
contract-generator-java/
├── pom.xml                         # Maven dependencies
├── src/main/java/com/contractgenerator/
│   ├── ContractGeneratorApplication.java  # JavaFX App entry point
│   ├── controller/                 # JavaFX Controllers (5 files)
│   ├── service/                    # Business logic (5 services)
│   ├── repository/                 # JPA Repositories (4 interfaces)
│   ├── entity/                     # JPA Entities (4 classes)
│   └── util/                       # Utilities (Word, PDF, CSV)
├── src/main/resources/
│   ├── fxml/                       # JavaFX layouts (5 FXML files)
│   ├── css/                        # Styling (application.css)
│   └── application.properties      # Configuration
└── target/
    └── contract-generator.jar      # Executable JAR
```

## 💾 Database

**SQLite** - Automatically created on first run:
```
contract-generator.db  (local file, ~5 MB)
```

**Tables:**
- `vendors` - Vendor information
- `contract_templates` - Available templates
- `generated_contracts` - Generated contract history
- `audit_logs` - Operation audit trail

## 📖 Usage

### 1. Add Vendors
- **Vendors Tab** → Click **+ Add Vendor**
- Fill form → Click **Save**
- Or: Import CSV (format: `name,email,phone,address,tax_id,contact_person`)

### 2. View Templates
- **Templates Tab** → See 6 built-in templates
- Upload custom `.docx` templates

### 3. Generate Contracts
- **Generate Tab** → Select **Vendor** + **Template**
- Choose export options: `.docx`, PDF, Print
- Click **Generate Contract**
- File auto-saves to `./generated-contracts/`

### 4. Review Audit Log
- **Audit Log Tab** → View all operations
- Filter by action/entity
- Clear log (optional)

## 🛠️ Customization

### Add Custom Template Fields

Edit Word template:
1. Open any `.docx` template
2. Add placeholders: `{vendorName}`, `{vendorEmail}`, etc.
3. Upload template via **Templates Tab**
4. Use in **Generate Tab**

### Database Location

Change in `application.properties`:
```properties
spring.datasource.url=jdbc:sqlite:/custom/path/contract-generator.db
```

### UI Styling

Modify `src/main/resources/css/application.css`

## 📊 Built-in Templates (6)

1. **Zmluva o poskytovaní služieb (Croner)** - Service agreement
2. **Nová Zmluva o pouzivani reklamnych predmetov (Croner)** - Advertising usage
3. **Dodatok c1 zoznam zakaznickych poziadaviek (Croner)** - Amendment 1
4. **Nová Zmluva o pouzivani reklamnych predmetov (AGRIOS)** - Advertising usage
5. **Szerződéskiegészítés természetes személlyel** - Contract amendment (HU)
6. **Dodatok c1 zoznam zakaznickych poziadaviek (AGRIOS)** - Amendment 1

## 🔒 Security Notes

- SQLite database stored locally: `./contract-generator.db`
- No network communication
- No data sent to external servers
- All processing happens locally

## ⚠️ Troubleshooting

### JAR won't run
```bash
# Check Java version
java -version  # Must be 17+

# Run with verbose output
java -jar target/contract-generator.jar --debug
```

### Database locked
```bash
# Close all instances
# Delete: contract-generator.db
# Restart application
```

### ClassNotFoundException
```bash
# Rebuild project
mvn clean compile package
```

## 📦 Distribution

### Create Installer (Windows)
```bash
# Install WiX Toolset
# Configure: pom.xml (maven-shade-plugin + wix-maven-plugin)
mvn clean package
```

### Create DMG (macOS)
```bash
jpackage --input target --name "Contract Generator" \
  --main-jar contract-generator.jar \
  --type dmg --mac-package-identifier com.contractgenerator
```

### Create AppImage (Linux)
```bash
jpackage --input target --name "Contract Generator" \
  --main-jar contract-generator.jar \
  --type app-image
```

## 🐛 Development

### Add Feature

1. Create entity in `entity/`
2. Create repository in `repository/`
3. Create service in `service/`
4. Create controller in `controller/`
5. Create/update FXML in `resources/fxml/`

### Run Tests
```bash
mvn test
```

## 📄 License

Private use - Modify as needed

## 👤 Author

Created: June 2026

---

**Questions?** Review the source code or check Spring Boot + JavaFX documentation.
