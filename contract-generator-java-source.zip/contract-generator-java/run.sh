#!/bin/bash
# Contract Generator - Launcher Script

JAR_PATH="/Users/krisztian/Library/Mobile Documents/com~apple~CloudDocs/Salary calculator/contract-generator-java/target/contract-generator-1.0.0.jar"

# Nézd meg, hogy létezik-e a database inicializáció segítségével
echo "Starting Contract Generator..."
/usr/local/opt/openjdk@17/bin/java -jar "$JAR_PATH"
